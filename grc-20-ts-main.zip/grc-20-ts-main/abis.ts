/**
 * This module provides ABIs for known smart contracts used in the knowledge graph.
 *
 * @since 0.0.6
 */

export * from './src/abis/index.js';
