/**
 * This module provides utility functions for working with Triples in TypeScript.
 *
 * @since 0.0.6
 */
export * as Triple from './core/triple.js';
