export const POLYGON = 'ReFDxuVQ674gHd2kFjsFL';
export const ETHEREUM = 'JnWfsCw2gqoPWFT1NXmFWW';
export const GEO = 'KJjKetFsGVSbw9qFpRzRSy';
