/**
 * This module provides utility functions for working with Relations in TypeScript.
 *
 * @since 0.0.6
 */

export * as Relation from './core/relation.js';
