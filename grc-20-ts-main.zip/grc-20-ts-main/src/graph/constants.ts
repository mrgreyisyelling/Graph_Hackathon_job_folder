export const DEFAULT_API_HOST = 'https://api-testnet.grc-20.thegraph.com';
