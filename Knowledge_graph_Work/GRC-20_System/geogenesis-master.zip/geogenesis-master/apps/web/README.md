### Getting started

```sh
# Run dev
pnpm dev

# Build web app
pnpm build

# Run production version of web app
pnpm build
pnpm start
```
