export const EditorH3 = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="8" height="10" viewBox="0 0 8 10" fill="none">
      <path
        d="M6.00636 0.949219V4.31833H2.16779V0.949219H0.400391V9.42722H2.16779V5.8648H6.00636V9.42722H7.77376V0.949219H6.00636Z"
        fill="black"
      />
    </svg>
  );
};
