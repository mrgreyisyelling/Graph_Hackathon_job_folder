export const EditorH1 = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" viewBox="0 0 16 18" fill="none">
      <path
        d="M11.7628 0.900391V7.48839H4.25678V0.900391H0.800781V17.4784H4.25678V10.5124H11.7628V17.4784H15.2188V0.900391H11.7628Z"
        fill="black"
      />
    </svg>
  );
};
