export const EditorH2 = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
      <path
        d="M8.58604 0.150391V4.95012H3.1175V0.150391H0.599609V12.2284H3.1175V7.15327H8.58604V12.2284H11.1039V0.150391H8.58604Z"
        fill="black"
      />
    </svg>
  );
};
