import { ColorThemeValue } from './colors';

export type Theme = {
  colors: ColorThemeValue;
};
