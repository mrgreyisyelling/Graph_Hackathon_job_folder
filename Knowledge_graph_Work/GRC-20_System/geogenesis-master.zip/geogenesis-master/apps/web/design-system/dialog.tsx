'use client';

import { Content, Overlay, Portal, Root, Trigger } from '@radix-ui/react-dialog';

import * as React from 'react';

import { SquareButton } from '~/design-system/button';
import { Close } from '~/design-system/icons/close';

interface Props {
  trigger: React.ReactNode;
  header: React.ReactNode;
  content: React.ReactNode;
}

export function Dialog(props: Props) {
  const [open, onOpenChange] = React.useState(false);

  return (
    <Root open={open} onOpenChange={onOpenChange}>
      <Trigger className="w-full">{props.trigger}</Trigger>

      <Portal>
        <Overlay className="fixed inset-0 z-100 bg-text bg-opacity-20" />

        <Content className="fixed inset-0 z-[101] flex items-start justify-center focus:outline-none">
          <div className="mt-40 inline-flex max-h-[415px] max-w-[586px] flex-col gap-3 overflow-y-auto rounded-lg bg-white p-4">
            <div className="flex items-center justify-between">
              {props.header}
              <SquareButton onClick={() => onOpenChange(false)} icon={<Close />} />
            </div>

            {props.content}
          </div>
        </Content>
      </Portal>
    </Root>
  );
}
