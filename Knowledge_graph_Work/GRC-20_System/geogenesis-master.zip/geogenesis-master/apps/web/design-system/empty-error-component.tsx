export function EmptyErrorComponent() {
  return <div />;
}
