import { ServicesProvider, useServices } from './services';

export const Services = {
  Provider: ServicesProvider,
  useServices,
};
