export function setImage() {
  return;
}
