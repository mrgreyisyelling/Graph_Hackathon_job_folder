export type { AppConfig } from './environment';
export * as Environment from './environment';
