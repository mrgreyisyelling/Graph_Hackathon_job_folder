export * as Cookie from './cookie';
export const HAS_DISMISSED_PERSONAL_SPACE_ONBOARDING_KEY = 'hasDismissedPersonalSpaceOnboarding';
export const WALLET_ADDRESS = 'walletAddress';
