'use client';

import * as React from 'react';

import { ResizableContainer } from '~/design-system/resizable-container';

export function MetadataMotionContainer({ children }: { children: React.ReactNode }) {
  return (
    <ResizableContainer duration={0.15}>
      <div className="my-3">{children}</div>
    </ResizableContainer>
  );
}
