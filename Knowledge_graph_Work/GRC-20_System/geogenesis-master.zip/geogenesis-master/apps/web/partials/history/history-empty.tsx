export function HistoryEmpty() {
  return (
    <h2 className="flex h-[59px] items-center justify-center bg-white text-metadataMedium">There is no history</h2>
  );
}
