import { Effect } from 'effect';

import { IpfsParseResponseError, IpfsUploadError } from '~/core/errors';

import { Metrics } from '../metrics';
import { Telemetry } from '../telemetry';

function upload(formData: FormData, url: string) {
  return Effect.gen(function* () {
    yield* Effect.logInfo(`Posting IPFS content to url`, url);

    const response = yield* Effect.tryPromise({
      try: () =>
        fetch(url, {
          method: 'POST',
          body: formData,
          headers: {
            Authorization: `Bearer ${process.env.IPFS_KEY}`,
          },
        }),
      catch: error => new IpfsUploadError(`IPFS upload failed: ${error}`),
    });

    const { Hash } = yield* Effect.tryPromise({
      try: () => response.json(),
      catch: error => new IpfsParseResponseError(`Could not parse IPFS JSON response: ${error}`),
    });

    return `ipfs://${Hash}` as const;
  });
}

export class IpfsService {
  constructor(public ipfsUrl: string) {}

  upload(binary: Uint8Array): Effect.Effect<`ipfs://${string}`, IpfsUploadError | IpfsParseResponseError> {
    const url = `${this.ipfsUrl}/api/v0/add`;

    return Effect.gen(function* () {
      const startTime = Date.now();

      const blob = new Blob([binary], { type: 'application/octet-stream' });
      const formData = new FormData();
      formData.append('file', blob);

      const hash = yield* upload(formData, url);

      const endTime = Date.now() - startTime;
      Telemetry.metric(Metrics.timing('ipfs_upload_binary_duration', endTime));
      yield* Effect.logInfo(`Uploaded binary to IPFS successfully`).pipe(Effect.annotateLogs({ hash }));

      return hash;
    });
  }

  uploadFile(file: File): Effect.Effect<`ipfs://${string}`, IpfsUploadError | IpfsParseResponseError> {
    const url = `${this.ipfsUrl}/api/v0/add`;

    return Effect.gen(function* () {
      yield* Effect.logInfo(`Uploading file to IPFS`);
      const startTime = Date.now();

      const formData = new FormData();
      formData.append('file', file);

      console.log('uploading file to ipfs', url);
      const hash = yield* upload(formData, url);

      const endTime = Date.now() - startTime;
      Telemetry.metric(Metrics.timing('ipfs_upload_file_duration', endTime));
      yield* Effect.logInfo(`Uploaded file to IPFS successfully`).pipe(Effect.annotateLogs({ hash }));

      return hash;
    });
  }
}
