'use client';

export const Component = () => {
  return (
    <div className="absolute left-0 top-0 z-100 min-h-screen w-full bg-black p-32 text-white">
      <div>um hai</div>
    </div>
  );
};
