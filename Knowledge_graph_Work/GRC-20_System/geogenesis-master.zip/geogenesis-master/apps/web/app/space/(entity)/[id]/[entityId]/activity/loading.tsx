import * as React from 'react';

import { ActivityLoading } from '~/partials/activity/activity-loading';

export default function Loading() {
  return <ActivityLoading />;
}
