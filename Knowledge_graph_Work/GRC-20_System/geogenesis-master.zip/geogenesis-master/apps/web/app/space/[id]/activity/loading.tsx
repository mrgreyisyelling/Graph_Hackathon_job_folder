import { ActivityLoading } from '~/partials/activity/activity-loading';

export default ActivityLoading;
