import { expect, test } from '@playwright/test';

test('checks editor has access to change content', async ({ page }) => {
  // await page.goto('/space/0x1A39E2Fe299Ef8f855ce43abF7AC85D6e69E05F5');

  // // Check that the Connect button is visible.
  // await expect(page.getByRole('button', { name: 'Connect' })).toBeVisible();
  // await page.getByRole('button', { name: 'Connect' }).click();

  // await page.getByTestId('edit-toggle').click();

  // await expect(page.getByTestId('create-entity-button')).toBeVisible();
  expect(true).toBe(true)
});
